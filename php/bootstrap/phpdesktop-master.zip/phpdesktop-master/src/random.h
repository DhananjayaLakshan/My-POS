#pragma once

#include "defines.h"

void srand2();
int random(unsigned int min, unsigned int max, int recursion_level=0);
