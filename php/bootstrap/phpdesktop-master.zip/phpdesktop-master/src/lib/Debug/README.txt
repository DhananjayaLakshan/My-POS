Put libcef.lib and libcef_dll_wrapper.lib here.

The version of CEF to use can be found in the cef/README.txt file.
