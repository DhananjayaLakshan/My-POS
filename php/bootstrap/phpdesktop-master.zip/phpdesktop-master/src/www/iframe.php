<style type="text/css">@import url("style.css");</style>
<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<h1>IFrame</h1>

<p>To test whether a new option "Open frame in external browser"
    appears when showing the mouse context menu.</p>

<iframe src="/index.php"
        style="width: 400px; height: 300px;"></iframe>
